export default function AvisoIndisponivel({ children }) {
  return (
    <div role="alert" className="aviso">
      {children}
    </div>
  );
}
