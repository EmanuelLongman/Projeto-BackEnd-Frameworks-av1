export default function BotaoSenha({ tipo, rotulo, descricao, desabilitado, onEscolher }) {
  return (
    <button
      type="button"
      className={`botao-senha botao-senha--${tipo.toLowerCase()}`}
      disabled={desabilitado}
      onClick={() => onEscolher(tipo)}
    >
      <strong>{rotulo}</strong>
      <span>{descricao}</span>
    </button>
  );
}
