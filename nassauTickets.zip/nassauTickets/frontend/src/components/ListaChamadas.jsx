const NOMES_TIPO = { SP: 'Prioritária', SG: 'Geral', SE: 'Exames' };

export default function ListaChamadas({ chamadas }) {
  if (chamadas.length === 0) {
    return <p>Nenhuma senha chamada até o momento.</p>;
  }
  return (
    <ol className="chamadas" aria-live="polite">
      {chamadas.map((chamada, indice) => (
        <li key={chamada.numero} className={indice === 0 ? 'chamada chamada--atual' : 'chamada'}>
          <span className="chamada__numero">{chamada.numero}</span>
          <span>{NOMES_TIPO[chamada.tipo]}</span>
          <span>Guichê {chamada.guiche}</span>
          {chamada.ultimaChamada && <strong className="chamada__selo">Última chamada</strong>}
        </li>
      ))}
    </ol>
  );
}
