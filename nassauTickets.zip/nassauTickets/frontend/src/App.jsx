import { Link, Route, Routes } from 'react-router-dom';
import Atendente from './pages/Atendente.jsx';
import Painel from './pages/Painel.jsx';
import Totem from './pages/Totem.jsx';

function Inicio() {
  return (
    <main>
      <h1>nassauTickets</h1>
      <p>Controle de atendimento do laboratório. Escolha a tela:</p>
      <nav aria-label="Telas do sistema">
        <ul>
          <li><Link to="/totem">Totem do cliente</Link></li>
          <li><Link to="/painel">Painel de chamadas</Link></li>
          <li><Link to="/atendente">Guichê do atendente</Link></li>
        </ul>
      </nav>
    </main>
  );
}

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Inicio />} />
      <Route path="/totem" element={<Totem />} />
      <Route path="/painel" element={<Painel />} />
      <Route path="/atendente" element={<Atendente />} />
    </Routes>
  );
}
