const BASE_URL = import.meta.env.VITE_API_URL ?? '/api';
const TEMPO_LIMITE_MS = 5000;

/** Backend ou banco fora do ar (rede, timeout ou HTTP 503). */
export class ApiIndisponivelError extends Error {
  constructor(mensagem = 'Serviço temporariamente indisponível') {
    super(mensagem);
    this.name = 'ApiIndisponivelError';
  }
}

async function requisitar(caminho, opcoes = {}) {
  const controle = new AbortController();
  const timer = setTimeout(() => controle.abort(), TEMPO_LIMITE_MS);
  try {
    const resposta = await fetch(`${BASE_URL}${caminho}`, {
      headers: { 'Content-Type': 'application/json' },
      signal: controle.signal,
      ...opcoes,
    });
    if (resposta.status === 503) throw new ApiIndisponivelError();
    const corpo = await resposta.json().catch(() => ({}));
    if (!resposta.ok) throw new Error(corpo.mensagem ?? 'Erro inesperado.');
    return corpo;
  } catch (erro) {
    if (erro.name === 'AbortError' || erro instanceof TypeError) throw new ApiIndisponivelError();
    throw erro;
  } finally {
    clearTimeout(timer);
  }
}

export const verificarSaude = () => requisitar('/health');
export const emitirSenha = (tipo) =>
  requisitar('/senhas', { method: 'POST', body: JSON.stringify({ tipo }) });
export const buscarPainel = () => requisitar('/painel');
