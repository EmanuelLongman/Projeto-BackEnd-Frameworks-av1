import { useEffect, useRef, useState } from 'react';
import AvisoIndisponivel from '../components/AvisoIndisponivel.jsx';
import ListaChamadas from '../components/ListaChamadas.jsx';
import { buscarPainel } from '../services/api.js';
import { falar, montarTextoChamada } from '../utils/audio.js';

const INTERVALO_MS = 3000;
const chaveDe = (chamada) => (chamada ? `${chamada.numero}|${chamada.chamadaEm}` : null);

export default function Painel() {
  const [chamadas, setChamadas] = useState([]);
  const [semConexao, setSemConexao] = useState(false);
  const [audioAtivo, setAudioAtivo] = useState(false);
  const ultimaFalada = useRef(null);

  // Atualiza o painel periodicamente. Em falha, mantém a última lista conhecida (RNF34).
  useEffect(() => {
    let ativo = true;
    async function atualizar() {
      try {
        const dados = await buscarPainel();
        if (!ativo) return;
        setChamadas(dados);
        setSemConexao(false);
      } catch {
        if (ativo) setSemConexao(true);
      }
    }
    atualizar();
    const id = setInterval(atualizar, INTERVALO_MS);
    return () => {
      ativo = false;
      clearInterval(id);
    };
  }, []);

  // Fala apenas chamadas novas (RF09 e RF10).
  useEffect(() => {
    if (!audioAtivo || chamadas.length === 0) return;
    const chave = chaveDe(chamadas[0]);
    if (chave === ultimaFalada.current) return;
    ultimaFalada.current = chave;
    falar(montarTextoChamada(chamadas[0]));
  }, [chamadas, audioAtivo]);

  function ativarAudio() {
    // Navegadores só liberam áudio após um clique do usuário.
    ultimaFalada.current = chaveDe(chamadas[0]);
    setAudioAtivo(true);
  }

  return (
    <main className="painel">
      <h1>Painel de chamadas</h1>

      {semConexao && (
        <AvisoIndisponivel>Sem conexão. As informações podem estar desatualizadas.</AvisoIndisponivel>
      )}

      {!audioAtivo && (
        <button type="button" onClick={ativarAudio}>Ativar áudio das chamadas</button>
      )}

      <ListaChamadas chamadas={chamadas} />
    </main>
  );
}
