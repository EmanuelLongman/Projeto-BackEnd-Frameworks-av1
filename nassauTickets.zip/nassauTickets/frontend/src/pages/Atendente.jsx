import { useState } from 'react';

const ETAPA = { LIVRE: 'LIVRE', CHAMADA: 'CHAMADA', EM_ATENDIMENTO: 'EM_ATENDIMENTO' };
const MAX_CHAMADAS = 2; // RN08

// Esqueleto da tela do atendente. Os handlers apenas simulam o fluxo no estado local;
// na próxima etapa serão trocados por chamadas à API (chamar, iniciar, finalizar).
export default function Atendente() {
  const [etapa, setEtapa] = useState(ETAPA.LIVRE);
  const [chamadas, setChamadas] = useState(0);
  const guiche = 1; // TODO: virá do login e da escolha do guichê

  function chamarProximo() {
    setChamadas(1);
    setEtapa(ETAPA.CHAMADA);
  }
  function chamarNovamente() {
    setChamadas((n) => n + 1);
  }
  function iniciar() {
    setEtapa(ETAPA.EM_ATENDIMENTO);
  }
  function encerrar() {
    setChamadas(0);
    setEtapa(ETAPA.LIVRE);
  }

  return (
    <main className="atendente">
      <h1>Guichê {guiche}</h1>
      <p>Situação: {etapa === ETAPA.LIVRE ? 'livre' : etapa === ETAPA.CHAMADA ? `aguardando o cliente (chamada ${chamadas} de ${MAX_CHAMADAS})` : 'em atendimento'}</p>

      {etapa === ETAPA.LIVRE && (
        <button type="button" onClick={chamarProximo}>Chamar próximo</button>
      )}

      {etapa === ETAPA.CHAMADA && (
        <div className="acoes">
          <button type="button" onClick={iniciar}>Iniciar atendimento</button>
          {chamadas < MAX_CHAMADAS && (
            <button type="button" onClick={chamarNovamente}>Chamar novamente</button>
          )}
          {chamadas >= MAX_CHAMADAS && (
            <button type="button" onClick={encerrar}>Cliente não compareceu</button>
          )}
        </div>
      )}

      {etapa === ETAPA.EM_ATENDIMENTO && (
        <button type="button" onClick={encerrar}>Finalizar atendimento</button>
      )}
    </main>
  );
}
