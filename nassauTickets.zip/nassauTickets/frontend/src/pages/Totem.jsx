import { useEffect, useState } from 'react';
import AvisoIndisponivel from '../components/AvisoIndisponivel.jsx';
import BotaoSenha from '../components/BotaoSenha.jsx';
import { ApiIndisponivelError, emitirSenha, verificarSaude } from '../services/api.js';

const OPCOES = [
  { tipo: 'SP', rotulo: 'Prioritária', descricao: 'Idosos, gestantes, pessoas com deficiência e demais casos previstos em lei' },
  { tipo: 'SG', rotulo: 'Atendimento geral', descricao: 'Coleta e demais serviços' },
  { tipo: 'SE', rotulo: 'Retirada de exames', descricao: 'Apenas retirada de resultados' },
];
const INTERVALO_RECONEXAO_MS = 5000;

export default function Totem() {
  const [senha, setSenha] = useState(null);
  const [carregando, setCarregando] = useState(false);
  const [erro, setErro] = useState(null);
  const [indisponivel, setIndisponivel] = useState(false);

  // Com o backend fora, tenta reconectar sozinho (RNF33).
  useEffect(() => {
    if (!indisponivel) return undefined;
    const id = setInterval(async () => {
      try {
        await verificarSaude();
        setIndisponivel(false);
      } catch {
        // continua tentando
      }
    }, INTERVALO_RECONEXAO_MS);
    return () => clearInterval(id);
  }, [indisponivel]);

  async function escolherTipo(tipo) {
    setCarregando(true);
    setErro(null);
    try {
      setSenha(await emitirSenha(tipo));
    } catch (e) {
      if (e instanceof ApiIndisponivelError) setIndisponivel(true);
      else setErro(e.message);
    } finally {
      setCarregando(false);
    }
  }

  return (
    <main className="totem">
      <h1>Retire sua senha</h1>

      {indisponivel && (
        <AvisoIndisponivel>Sistema temporariamente indisponível. Dirija-se à recepção.</AvisoIndisponivel>
      )}
      {erro && <AvisoIndisponivel>{erro}</AvisoIndisponivel>}

      <div className="totem__opcoes">
        {OPCOES.map((opcao) => (
          <BotaoSenha
            key={opcao.tipo}
            {...opcao}
            desabilitado={carregando || indisponivel}
            onEscolher={escolherTipo}
          />
        ))}
      </div>

      {senha && (
        <section className="comprovante" aria-live="polite">
          <h2>Sua senha</h2>
          <p className="comprovante__numero">{senha.numero}</p>
          <p>Aguarde ser chamado no painel.</p>
          <button type="button" onClick={() => window.print()}>Imprimir comprovante</button>
        </section>
      )}
    </main>
  );
}
