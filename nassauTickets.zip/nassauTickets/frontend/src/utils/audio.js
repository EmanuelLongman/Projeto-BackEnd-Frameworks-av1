const NOMES_TIPO = { SP: 'prioritária', SG: 'geral', SE: 'de exames' };

/** Texto lido na chamada: prioridade, sequencial e guichê (RN15). */
export function montarTextoChamada({ tipo, numero, guiche, ultimaChamada }) {
  const sequencial = numero.slice(-3).split('').join(' ');
  const prefixo = ultimaChamada ? 'Última chamada. ' : '';
  return `${prefixo}Senha ${NOMES_TIPO[tipo]}, ${sequencial}. Guichê ${guiche}.`;
}

export function falar(texto) {
  if (!('speechSynthesis' in window)) return;
  window.speechSynthesis.cancel();
  const fala = new SpeechSynthesisUtterance(texto);
  fala.lang = 'pt-BR';
  window.speechSynthesis.speak(fala);
}
