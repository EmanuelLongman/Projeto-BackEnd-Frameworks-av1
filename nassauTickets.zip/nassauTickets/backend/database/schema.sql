-- nassauTickets - esquema inicial (MySQL 8.0)
CREATE DATABASE IF NOT EXISTS nassautickets
  CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
USE nassautickets;

CREATE TABLE usuarios (
  id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nome        VARCHAR(100) NOT NULL,
  login       VARCHAR(50)  NOT NULL UNIQUE,
  senha_hash  VARCHAR(255) NOT NULL,
  eh_gestor   BOOLEAN      NOT NULL DEFAULT FALSE, -- apenas um gestor (regra da aplicação)
  ativo       BOOLEAN      NOT NULL DEFAULT TRUE
);

CREATE TABLE guiches (
  id      INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  numero  TINYINT UNSIGNED NOT NULL UNIQUE,
  ativo   BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE senhas (
  id                     BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  numero                 CHAR(12) NOT NULL UNIQUE,            -- YYMMDD-PPSQ
  tipo                   ENUM('SP','SG','SE') NOT NULL,
  sequencia              SMALLINT UNSIGNED NOT NULL,
  data_ref               DATE NOT NULL,
  estado                 ENUM('EMITIDA','AGUARDANDO','CHAMADA','CHAMADA_NOVAMENTE',
                              'EM_ATENDIMENTO','ATENDIDA','NAO_COMPARECEU') NOT NULL,
  guiche_id              INT UNSIGNED NULL,
  atendente_id           INT UNSIGNED NULL,
  emitida_em             DATETIME NOT NULL,
  primeira_chamada_em    DATETIME NULL,
  segunda_chamada_em     DATETIME NULL,
  inicio_atendimento_em  DATETIME NULL,
  fim_atendimento_em     DATETIME NULL,
  descartada_em          DATETIME NULL,                       -- sobra no fim do expediente
  UNIQUE KEY uq_senha_dia (data_ref, tipo, sequencia),
  KEY idx_fila (data_ref, estado, tipo, sequencia),
  CONSTRAINT fk_senha_guiche    FOREIGN KEY (guiche_id)    REFERENCES guiches (id),
  CONSTRAINT fk_senha_atendente FOREIGN KEY (atendente_id) REFERENCES usuarios (id)
);

-- Histórico append-only usado na auditoria
CREATE TABLE eventos_senha (
  id            BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  senha_id      BIGINT UNSIGNED NOT NULL,
  estado        VARCHAR(20) NOT NULL,
  ocorrido_em   DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  atendente_id  INT UNSIGNED NULL,
  guiche_id     INT UNSIGNED NULL,
  KEY idx_evento_senha (senha_id),
  CONSTRAINT fk_evento_senha FOREIGN KEY (senha_id) REFERENCES senhas (id)
);

-- Sequencial por tipo e dia
CREATE TABLE contadores_senha (
  tipo        ENUM('SP','SG','SE') NOT NULL,
  data_ref    DATE NOT NULL,
  ultimo_seq  SMALLINT UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY (tipo, data_ref)
);

-- Linha única travada (FOR UPDATE) para serializar "chamar próximo"
CREATE TABLE fila_controle (
  id           TINYINT UNSIGNED PRIMARY KEY,
  data_ref     DATE NULL,
  ultimo_tipo  ENUM('SP','SE','SG') NULL
);
INSERT INTO fila_controle (id) VALUES (1);
