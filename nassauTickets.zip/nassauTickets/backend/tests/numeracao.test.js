import assert from 'node:assert/strict';
import { describe, it } from 'node:test';
import { dentroDoExpediente } from '../src/utils/expediente.js';
import { dataReferencia, formatarNumero } from '../src/utils/numeracao.js';

describe('formatarNumero (RN02)', () => {
  it('segue o padrão YYMMDD-PPSQ', () => {
    const data = new Date(2026, 9, 4, 8, 30); // 04/10/2026
    assert.equal(formatarNumero(data, 'SG', 7), '261004-SG007');
    assert.equal(formatarNumero(data, 'SP', 1), '261004-SP001');
    assert.equal(formatarNumero(data, 'SE', 120), '261004-SE120');
  });

  it('gera sempre 12 caracteres', () => {
    assert.equal(formatarNumero(new Date(2027, 0, 9), 'SP', 999).length, 12);
  });
});

describe('dataReferencia', () => {
  it('usa a data local no formato YYYY-MM-DD', () => {
    assert.equal(dataReferencia(new Date(2026, 0, 5, 23, 59)), '2026-01-05');
  });
});

describe('dentroDoExpediente (RN11)', () => {
  it('aceita de 7h00 até 16h59', () => {
    assert.equal(dentroDoExpediente(new Date(2026, 9, 5, 7, 0)), true);
    assert.equal(dentroDoExpediente(new Date(2026, 9, 5, 16, 59)), true);
  });

  it('recusa antes das 7h e a partir das 17h', () => {
    assert.equal(dentroDoExpediente(new Date(2026, 9, 5, 6, 59)), false);
    assert.equal(dentroDoExpediente(new Date(2026, 9, 5, 17, 0)), false);
  });
});
