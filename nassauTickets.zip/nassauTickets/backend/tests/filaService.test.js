import assert from 'node:assert/strict';
import { describe, it } from 'node:test';
import { escolherProximoTipo } from '../src/services/filaService.js';

const cheias = { SP: 5, SE: 5, SG: 5 };

describe('escolherProximoTipo (RN05 e RN06)', () => {
  it('começa em SP quando ainda não houve chamada', () => {
    assert.equal(escolherProximoTipo(null, cheias), 'SP');
  });

  it('segue o ciclo SP -> SE -> SG -> SP', () => {
    assert.equal(escolherProximoTipo('SP', cheias), 'SE');
    assert.equal(escolherProximoTipo('SE', cheias), 'SG');
    assert.equal(escolherProximoTipo('SG', cheias), 'SP');
  });

  it('pula a fila vazia e vai para o próximo tipo do ciclo', () => {
    assert.equal(escolherProximoTipo('SP', { SP: 2, SE: 0, SG: 3 }), 'SG');
    assert.equal(escolherProximoTipo('SG', { SP: 0, SE: 1, SG: 3 }), 'SE');
  });

  it('repete o tipo quando é o único com senhas', () => {
    assert.equal(escolherProximoTipo('SP', { SP: 4, SE: 0, SG: 0 }), 'SP');
  });

  it('não deixa SG esperando para sempre quando há muitas SP', () => {
    const chamadas = [];
    let ultimo = null;
    for (let i = 0; i < 6; i += 1) {
      ultimo = escolherProximoTipo(ultimo, cheias);
      chamadas.push(ultimo);
    }
    assert.deepEqual(chamadas, ['SP', 'SE', 'SG', 'SP', 'SE', 'SG']);
  });

  it('retorna null quando todas as filas estão vazias', () => {
    assert.equal(escolherProximoTipo('SG', { SP: 0, SE: 0, SG: 0 }), null);
    assert.equal(escolherProximoTipo(null, {}), null);
  });
});
