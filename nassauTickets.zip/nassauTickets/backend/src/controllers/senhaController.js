import { emitirSenha, listarPainel } from '../services/senhaService.js';

export async function emitir(req, res, next) {
  try {
    const senha = await emitirSenha(req.body?.tipo);
    res.status(201).json(senha);
  } catch (erro) {
    next(erro);
  }
}

export async function painel(req, res, next) {
  try {
    res.json(await listarPainel());
  } catch (erro) {
    next(erro);
  }
}
