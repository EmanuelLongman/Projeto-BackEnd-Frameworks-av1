// Ordem do ciclo de atendimento (RN05): SP -> SE -> SG -> SP ...
export const CICLO = ['SP', 'SE', 'SG'];
export const TIPOS = CICLO;

/**
 * Decide o tipo da próxima senha a ser chamada.
 * @param {string|null} ultimoTipo tipo chamado por último (null se ainda não houve)
 * @param {{SP?: number, SE?: number, SG?: number}} filas quantidade aguardando por tipo
 * @returns {string|null} tipo escolhido, ou null se todas as filas estiverem vazias
 */
export function escolherProximoTipo(ultimoTipo, filas) {
  const posicaoAtual = CICLO.indexOf(ultimoTipo); // -1 => começa em SP
  for (let passo = 1; passo <= CICLO.length; passo += 1) {
    const tipo = CICLO[(posicaoAtual + passo) % CICLO.length];
    if ((filas[tipo] ?? 0) > 0) return tipo;
  }
  return null;
}
