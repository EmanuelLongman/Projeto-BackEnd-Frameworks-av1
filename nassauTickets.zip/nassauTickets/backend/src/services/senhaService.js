import pool from '../config/db.js';
import { ErroNegocio } from '../utils/erros.js';
import { dentroDoExpediente } from '../utils/expediente.js';
import { dataReferencia, formatarNumero } from '../utils/numeracao.js';
import { TIPOS } from './filaService.js';

const SEQUENCIAL_MAXIMO = 999;

async function registrarEvento(conn, senhaId, estado) {
  await conn.execute('INSERT INTO eventos_senha (senha_id, estado) VALUES (?, ?)', [senhaId, estado]);
}

/** Emite uma senha: gera o sequencial, grava e coloca na fila (EMITIDA -> AGUARDANDO). */
export async function emitirSenha(tipo, agora = new Date()) {
  if (!TIPOS.includes(tipo)) {
    throw new ErroNegocio('Tipo de senha inválido. Use SP, SG ou SE.', 400);
  }
  if (!dentroDoExpediente(agora)) {
    throw new ErroNegocio('Fora do horário de atendimento (7h às 17h).', 422);
  }

  const dataRef = dataReferencia(agora);
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();

    // Garante a linha do contador e a trava até o fim da transação (evita sequencial repetido).
    await conn.execute(
      'INSERT IGNORE INTO contadores_senha (tipo, data_ref, ultimo_seq) VALUES (?, ?, 0)',
      [tipo, dataRef],
    );
    const [[contador]] = await conn.execute(
      'SELECT ultimo_seq FROM contadores_senha WHERE tipo = ? AND data_ref = ? FOR UPDATE',
      [tipo, dataRef],
    );
    const sequencia = contador.ultimo_seq + 1;
    if (sequencia > SEQUENCIAL_MAXIMO) {
      throw new ErroNegocio(`Limite diário de senhas ${tipo} atingido.`, 409);
    }
    await conn.execute(
      'UPDATE contadores_senha SET ultimo_seq = ? WHERE tipo = ? AND data_ref = ?',
      [sequencia, tipo, dataRef],
    );

    const numero = formatarNumero(agora, tipo, sequencia);
    const [resultado] = await conn.execute(
      `INSERT INTO senhas (numero, tipo, sequencia, data_ref, estado, emitida_em)
       VALUES (?, ?, ?, ?, 'EMITIDA', ?)`,
      [numero, tipo, sequencia, dataRef, agora],
    );
    await registrarEvento(conn, resultado.insertId, 'EMITIDA');

    await conn.execute("UPDATE senhas SET estado = 'AGUARDANDO' WHERE id = ?", [resultado.insertId]);
    await registrarEvento(conn, resultado.insertId, 'AGUARDANDO');

    await conn.commit();
    return { numero, tipo, estado: 'AGUARDANDO', emitidaEm: agora.toISOString() };
  } catch (erro) {
    await conn.rollback();
    throw erro;
  } finally {
    conn.release();
  }
}

/** Últimas 5 senhas chamadas no dia (RN14). Nunca inclui a próxima da fila. */
export async function listarPainel() {
  const [linhas] = await pool.execute(
    `SELECT s.numero, s.tipo, g.numero AS guiche,
            COALESCE(s.segunda_chamada_em, s.primeira_chamada_em) AS chamada_em,
            s.segunda_chamada_em IS NOT NULL AS ultima_chamada
       FROM senhas s
       JOIN guiches g ON g.id = s.guiche_id
      WHERE s.primeira_chamada_em IS NOT NULL
        AND s.data_ref = CURDATE()
      ORDER BY chamada_em DESC
      LIMIT 5`,
  );
  return linhas.map((l) => ({
    numero: l.numero,
    tipo: l.tipo,
    guiche: l.guiche,
    ultimaChamada: Boolean(l.ultima_chamada),
    chamadaEm: l.chamada_em,
  }));
}
