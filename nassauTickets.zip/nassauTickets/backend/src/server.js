import 'dotenv/config'; // precisa ser o primeiro import: carrega o .env antes do restante
import app from './app.js';

const PORT = Number(process.env.PORT ?? 3000);

const servidor = app.listen(PORT, () => {
  console.log(`nassauTickets API em http://localhost:${PORT}`);
});

function encerrar(sinal) {
  console.log(`${sinal} recebido, encerrando...`);
  servidor.close(() => process.exit(0));
}
process.on('SIGINT', () => encerrar('SIGINT'));
process.on('SIGTERM', () => encerrar('SIGTERM'));
