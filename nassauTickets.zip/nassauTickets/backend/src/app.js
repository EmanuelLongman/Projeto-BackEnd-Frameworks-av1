import cors from 'cors';
import express from 'express';
import helmet from 'helmet';
import { rotaNaoEncontrada, tratarErros } from './middlewares/erros.js';
import routes from './routes/index.js';

const app = express();

app.use(helmet());
app.use(cors({ origin: (process.env.CORS_ORIGIN ?? 'http://localhost:5173').split(',') }));
app.use(express.json({ limit: '10kb' }));

app.use('/api', routes);

app.use(rotaNaoEncontrada);
app.use(tratarErros);

export default app;
