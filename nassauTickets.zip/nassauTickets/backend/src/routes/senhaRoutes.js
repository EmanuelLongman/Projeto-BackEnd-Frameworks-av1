import { Router } from 'express';
import { emitir, painel } from '../controllers/senhaController.js';

const router = Router();

router.post('/senhas', emitir); // Totem: emite uma senha
router.get('/painel', painel); // Painel: 5 últimas chamadas

export default router;
