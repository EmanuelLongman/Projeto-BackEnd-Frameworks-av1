import { Router } from 'express';
import pool from '../config/db.js';
import senhaRoutes from './senhaRoutes.js';

const router = Router();

// Verifica a API e o banco (RNF28). Responde 503 se o banco estiver fora.
router.get('/health', async (req, res) => {
  try {
    await pool.query('SELECT 1');
    res.json({ status: 'ok', banco: 'ok', horario: new Date().toISOString() });
  } catch {
    res.status(503).json({ status: 'degradado', banco: 'indisponivel' });
  }
});

router.use(senhaRoutes);

export default router;
