import { ErroNegocio } from '../utils/erros.js';

const ERROS_DE_CONEXAO = new Set([
  'ECONNREFUSED',
  'ENOTFOUND',
  'ETIMEDOUT',
  'PROTOCOL_CONNECTION_LOST',
  'ER_CON_COUNT_ERROR',
]);

export function rotaNaoEncontrada(req, res) {
  res.status(404).json({ mensagem: 'Rota não encontrada.' });
}

// Nunca expõe stack trace ou SQL ao cliente (RNF09).
// eslint-disable-next-line no-unused-vars
export function tratarErros(erro, req, res, _next) {
  if (erro instanceof ErroNegocio) {
    return res.status(erro.status).json({ mensagem: erro.message });
  }
  if (erro.type === 'entity.parse.failed') {
    return res.status(400).json({ mensagem: 'JSON inválido.' });
  }
  if (ERROS_DE_CONEXAO.has(erro.code)) {
    console.error('[banco] indisponível:', erro.code);
    return res.status(503).json({ mensagem: 'Serviço temporariamente indisponível.' });
  }
  console.error('[erro]', erro);
  return res.status(500).json({ mensagem: 'Erro interno do servidor.' });
}
