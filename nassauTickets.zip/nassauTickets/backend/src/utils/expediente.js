export const HORA_INICIO = 7;
export const HORA_FIM = 17;

/** Expediente das 7h (inclusive) às 17h (exclusive) - RN11. */
export function dentroDoExpediente(data = new Date()) {
  const hora = data.getHours();
  return hora >= HORA_INICIO && hora < HORA_FIM;
}
