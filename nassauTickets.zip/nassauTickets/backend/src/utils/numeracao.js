const doisDigitos = (n) => String(n).padStart(2, '0');

/** Data local no formato YYYY-MM-DD (usada como chave diária do sequencial). */
export function dataReferencia(data = new Date()) {
  return `${data.getFullYear()}-${doisDigitos(data.getMonth() + 1)}-${doisDigitos(data.getDate())}`;
}

/** Monta o número da senha no padrão YYMMDD-PPSQ (RN02). */
export function formatarNumero(data, tipo, sequencia) {
  const yy = doisDigitos(data.getFullYear() % 100);
  const mm = doisDigitos(data.getMonth() + 1);
  const dd = doisDigitos(data.getDate());
  return `${yy}${mm}${dd}-${tipo}${String(sequencia).padStart(3, '0')}`;
}
